import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const listEmailTemplates = query({
  args: {
    type: v.optional(v.union(
      v.literal("cold-outreach"),
      v.literal("follow-up"),
      v.literal("proposal"),
      v.literal("thank-you")
    )),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    let query = ctx.db
      .query("emailTemplates")
      .withIndex("by_user", (q) => q.eq("userId", userId));

    if (args.type) {
      query = ctx.db
        .query("emailTemplates")
        .withIndex("by_type", (q) => q.eq("userId", userId).eq("type", args.type as any));
    }

    return await query.order("desc").collect();
  },
});

export const createEmailTemplate = mutation({
  args: {
    name: v.string(),
    subject: v.string(),
    body: v.string(),
    type: v.union(
      v.literal("cold-outreach"),
      v.literal("follow-up"),
      v.literal("proposal"),
      v.literal("thank-you")
    ),
    isDefault: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // If this is being set as default, unset other defaults of the same type
    if (args.isDefault) {
      const existingDefaults = await ctx.db
        .query("emailTemplates")
        .withIndex("by_type", (q) => q.eq("userId", userId).eq("type", args.type))
        .filter((q) => q.eq(q.field("isDefault"), true))
        .collect();

      for (const template of existingDefaults) {
        await ctx.db.patch(template._id, { isDefault: false });
      }
    }

    return await ctx.db.insert("emailTemplates", {
      ...args,
      userId,
    });
  },
});

export const updateEmailTemplate = mutation({
  args: {
    templateId: v.id("emailTemplates"),
    updates: v.object({
      name: v.optional(v.string()),
      subject: v.optional(v.string()),
      body: v.optional(v.string()),
      isDefault: v.optional(v.boolean()),
    }),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const template = await ctx.db.get(args.templateId);
    if (!template || template.userId !== userId) {
      throw new Error("Template not found or unauthorized");
    }

    // If this is being set as default, unset other defaults of the same type
    if (args.updates.isDefault) {
      const existingDefaults = await ctx.db
        .query("emailTemplates")
        .withIndex("by_type", (q) => q.eq("userId", userId).eq("type", template.type))
        .filter((q) => q.eq(q.field("isDefault"), true))
        .collect();

      for (const existingTemplate of existingDefaults) {
        if (existingTemplate._id !== args.templateId) {
          await ctx.db.patch(existingTemplate._id, { isDefault: false });
        }
      }
    }

    await ctx.db.patch(args.templateId, args.updates);
  },
});

export const deleteEmailTemplate = mutation({
  args: {
    templateId: v.id("emailTemplates"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const template = await ctx.db.get(args.templateId);
    if (!template || template.userId !== userId) {
      throw new Error("Template not found or unauthorized");
    }

    await ctx.db.delete(args.templateId);
  },
});

// Default templates to create for new users
export const createDefaultTemplates = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const defaultTemplates = [
      {
        name: "Cold Outreach - Introduction",
        subject: "Quick question about {{company_name}}",
        body: `Hi {{first_name}},

I hope this email finds you well. I came across {{company_name}} and was impressed by your work in {{industry}}.

I'm reaching out because I believe we might be able to help {{company_name}} with {{value_proposition}}.

Would you be open to a brief 15-minute call this week to discuss how we could potentially support your goals?

Best regards,
{{your_name}}`,
        type: "cold-outreach" as const,
        isDefault: true,
      },
      {
        name: "Follow-up - After Initial Contact",
        subject: "Following up on our conversation",
        body: `Hi {{first_name}},

Thank you for taking the time to speak with me yesterday about {{company_name}}'s {{discussion_topic}}.

As promised, I'm attaching some additional information that might be helpful for your evaluation.

I'd love to continue our conversation and explore how we can support {{company_name}}'s objectives. Are you available for a follow-up call next week?

Best regards,
{{your_name}}`,
        type: "follow-up" as const,
        isDefault: true,
      },
      {
        name: "Proposal - Solution Presentation",
        subject: "Proposal for {{company_name}} - {{solution_name}}",
        body: `Hi {{first_name}},

Thank you for your interest in our solutions for {{company_name}}.

Based on our discussions, I've prepared a customized proposal that addresses your specific needs around {{pain_points}}.

The attached proposal outlines:
- Our recommended solution approach
- Timeline and implementation plan
- Investment details
- Expected outcomes and ROI

I'm confident this solution will help {{company_name}} achieve {{desired_outcomes}}.

I'd be happy to schedule a call to walk through the proposal and answer any questions you might have.

Best regards,
{{your_name}}`,
        type: "proposal" as const,
        isDefault: true,
      },
      {
        name: "Thank You - Post Meeting",
        subject: "Thank you for your time today",
        body: `Hi {{first_name}},

Thank you for taking the time to meet with me today. I really enjoyed our conversation about {{company_name}}'s {{discussion_topic}}.

As discussed, I'll {{next_steps}} and follow up with you by {{follow_up_date}}.

If you have any questions in the meantime, please don't hesitate to reach out.

Looking forward to continuing our partnership!

Best regards,
{{your_name}}`,
        type: "thank-you" as const,
        isDefault: true,
      },
    ];

    for (const template of defaultTemplates) {
      await ctx.db.insert("emailTemplates", {
        ...template,
        userId,
      });
    }
  },
});
