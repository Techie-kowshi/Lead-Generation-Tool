import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const listLists = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db
      .query("lists")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const createList = mutation({
  args: {
    name: v.string(),
    description: v.optional(v.string()),
    companyIds: v.array(v.id("companies")),
    tags: v.optional(v.array(v.string())),
    isPublic: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db.insert("lists", {
      ...args,
      userId,
    });
  },
});

export const updateList = mutation({
  args: {
    listId: v.id("lists"),
    updates: v.object({
      name: v.optional(v.string()),
      description: v.optional(v.string()),
      companyIds: v.optional(v.array(v.id("companies"))),
      tags: v.optional(v.array(v.string())),
      isPublic: v.optional(v.boolean()),
    }),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const list = await ctx.db.get(args.listId);
    if (!list || list.userId !== userId) {
      throw new Error("List not found or unauthorized");
    }

    await ctx.db.patch(args.listId, args.updates);
  },
});

export const addCompaniesToList = mutation({
  args: {
    listId: v.id("lists"),
    companyIds: v.array(v.id("companies")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const list = await ctx.db.get(args.listId);
    if (!list || list.userId !== userId) {
      throw new Error("List not found or unauthorized");
    }

    const updatedCompanyIds = [...new Set([...list.companyIds, ...args.companyIds])];
    await ctx.db.patch(args.listId, { companyIds: updatedCompanyIds });
  },
});

export const removeCompaniesFromList = mutation({
  args: {
    listId: v.id("lists"),
    companyIds: v.array(v.id("companies")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const list = await ctx.db.get(args.listId);
    if (!list || list.userId !== userId) {
      throw new Error("List not found or unauthorized");
    }

    const updatedCompanyIds = list.companyIds.filter(id => !args.companyIds.includes(id));
    await ctx.db.patch(args.listId, { companyIds: updatedCompanyIds });
  },
});

export const deleteList = mutation({
  args: {
    listId: v.id("lists"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const list = await ctx.db.get(args.listId);
    if (!list || list.userId !== userId) {
      throw new Error("List not found or unauthorized");
    }

    await ctx.db.delete(args.listId);
  },
});
