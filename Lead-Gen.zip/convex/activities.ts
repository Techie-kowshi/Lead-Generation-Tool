import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const listActivities = query({
  args: {
    companyId: v.optional(v.id("companies")),
    contactId: v.optional(v.id("contacts")),
    status: v.optional(v.union(v.literal("pending"), v.literal("completed"), v.literal("cancelled"))),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    let query = ctx.db
      .query("activities")
      .withIndex("by_user", (q) => q.eq("userId", userId));

    if (args.companyId) {
      query = ctx.db
        .query("activities")
        .withIndex("by_company", (q) => q.eq("companyId", args.companyId));
    }

    if (args.contactId) {
      query = ctx.db
        .query("activities")
        .withIndex("by_contact", (q) => q.eq("contactId", args.contactId));
    }

    if (args.status) {
      query = ctx.db
        .query("activities")
        .withIndex("by_status", (q) => q.eq("userId", userId).eq("status", args.status as any));
    }

    return await query.order("desc").take(args.limit || 50);
  },
});

export const getUpcomingActivities = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const now = Date.now();
    const nextWeek = now + 7 * 24 * 60 * 60 * 1000;

    return await ctx.db
      .query("activities")
      .withIndex("by_scheduled_date", (q) => 
        q.eq("userId", userId)
         .gte("scheduledDate", now)
         .lte("scheduledDate", nextWeek)
      )
      .filter((q) => q.eq(q.field("status"), "pending"))
      .order("asc")
      .take(20);
  },
});

export const createActivity = mutation({
  args: {
    type: v.union(
      v.literal("email"),
      v.literal("call"),
      v.literal("meeting"),
      v.literal("note"),
      v.literal("task")
    ),
    subject: v.string(),
    description: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    contactId: v.optional(v.id("contacts")),
    scheduledDate: v.optional(v.number()),
    priority: v.optional(v.union(v.literal("low"), v.literal("medium"), v.literal("high"))),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    return await ctx.db.insert("activities", {
      ...args,
      userId,
      status: "pending",
    });
  },
});

export const updateActivity = mutation({
  args: {
    activityId: v.id("activities"),
    updates: v.object({
      subject: v.optional(v.string()),
      description: v.optional(v.string()),
      scheduledDate: v.optional(v.number()),
      status: v.optional(v.union(v.literal("pending"), v.literal("completed"), v.literal("cancelled"))),
      priority: v.optional(v.union(v.literal("low"), v.literal("medium"), v.literal("high"))),
      completedDate: v.optional(v.number()),
    }),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const activity = await ctx.db.get(args.activityId);
    if (!activity || activity.userId !== userId) {
      throw new Error("Activity not found or unauthorized");
    }

    await ctx.db.patch(args.activityId, args.updates);
  },
});

export const completeActivity = mutation({
  args: {
    activityId: v.id("activities"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const activity = await ctx.db.get(args.activityId);
    if (!activity || activity.userId !== userId) {
      throw new Error("Activity not found or unauthorized");
    }

    await ctx.db.patch(args.activityId, {
      status: "completed",
      completedDate: Date.now(),
    });
  },
});

export const deleteActivity = mutation({
  args: {
    activityId: v.id("activities"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const activity = await ctx.db.get(args.activityId);
    if (!activity || activity.userId !== userId) {
      throw new Error("Activity not found or unauthorized");
    }

    await ctx.db.delete(args.activityId);
  },
});
