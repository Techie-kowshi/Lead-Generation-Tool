import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  companies: defineTable({
    name: v.string(),
    domain: v.optional(v.string()),
    industry: v.optional(v.string()),
    size: v.optional(v.string()),
    location: v.optional(v.string()),
    description: v.optional(v.string()),
    linkedinUrl: v.optional(v.string()),
    website: v.optional(v.string()),
    founded: v.optional(v.string()),
    specialties: v.optional(v.array(v.string())),
    leadScore: v.optional(v.number()),
    enrichedAt: v.number(),
    userId: v.id("users"),
    revenue: v.optional(v.string()),
    employees: v.optional(v.number()),
    technologies: v.optional(v.array(v.string())),
    socialMedia: v.optional(v.object({
      twitter: v.optional(v.string()),
      facebook: v.optional(v.string()),
      instagram: v.optional(v.string()),
    })),
    contactInfo: v.optional(v.object({
      email: v.optional(v.string()),
      phone: v.optional(v.string()),
    })),
    tags: v.optional(v.array(v.string())),
    notes: v.optional(v.string()),
    status: v.optional(v.union(
      v.literal("new"),
      v.literal("contacted"),
      v.literal("qualified"),
      v.literal("proposal"),
      v.literal("closed-won"),
      v.literal("closed-lost")
    )),
    lastContactDate: v.optional(v.number()),
    nextFollowUp: v.optional(v.number()),
  })
    .index("by_user", ["userId"])
    .index("by_domain", ["domain"])
    .index("by_status", ["userId", "status"])
    .index("by_industry", ["userId", "industry"])
    .index("by_lead_score", ["userId", "leadScore"])
    .searchIndex("search_companies", {
      searchField: "name",
      filterFields: ["userId", "industry", "status"],
    }),

  contacts: defineTable({
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    title: v.optional(v.string()),
    department: v.optional(v.string()),
    linkedinUrl: v.optional(v.string()),
    companyId: v.id("companies"),
    userId: v.id("users"),
    isPrimary: v.optional(v.boolean()),
    lastContactDate: v.optional(v.number()),
    notes: v.optional(v.string()),
  })
    .index("by_company", ["companyId"])
    .index("by_user", ["userId"])
    .searchIndex("search_contacts", {
      searchField: "firstName",
      filterFields: ["userId", "companyId"],
    }),

  activities: defineTable({
    type: v.union(
      v.literal("email"),
      v.literal("call"),
      v.literal("meeting"),
      v.literal("note"),
      v.literal("task")
    ),
    subject: v.string(),
    description: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    contactId: v.optional(v.id("contacts")),
    userId: v.id("users"),
    scheduledDate: v.optional(v.number()),
    completedDate: v.optional(v.number()),
    status: v.union(v.literal("pending"), v.literal("completed"), v.literal("cancelled")),
    priority: v.optional(v.union(v.literal("low"), v.literal("medium"), v.literal("high"))),
  })
    .index("by_user", ["userId"])
    .index("by_company", ["companyId"])
    .index("by_contact", ["contactId"])
    .index("by_status", ["userId", "status"])
    .index("by_scheduled_date", ["userId", "scheduledDate"]),

  lists: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    userId: v.id("users"),
    companyIds: v.array(v.id("companies")),
    tags: v.optional(v.array(v.string())),
    isPublic: v.optional(v.boolean()),
  })
    .index("by_user", ["userId"]),

  emailTemplates: defineTable({
    name: v.string(),
    subject: v.string(),
    body: v.string(),
    type: v.union(
      v.literal("cold-outreach"),
      v.literal("follow-up"),
      v.literal("proposal"),
      v.literal("thank-you")
    ),
    userId: v.id("users"),
    isDefault: v.optional(v.boolean()),
  })
    .index("by_user", ["userId"])
    .index("by_type", ["userId", "type"]),

  enrichmentRequests: defineTable({
    input: v.string(),
    status: v.union(v.literal("pending"), v.literal("completed"), v.literal("failed")),
    result: v.optional(v.string()),
    userId: v.id("users"),
  }).index("by_user_status", ["userId", "status"]),

  integrations: defineTable({
    provider: v.union(
      v.literal("linkedin"),
      v.literal("salesforce"),
      v.literal("hubspot"),
      v.literal("pipedrive")
    ),
    accessToken: v.string(),
    refreshToken: v.optional(v.string()),
    expiresAt: v.optional(v.number()),
    userId: v.id("users"),
    isActive: v.boolean(),
    settings: v.optional(v.object({
      syncContacts: v.optional(v.boolean()),
      syncCompanies: v.optional(v.boolean()),
      autoEnrich: v.optional(v.boolean()),
    })),
  })
    .index("by_user", ["userId"])
    .index("by_provider", ["userId", "provider"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
