import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const listContacts = query({
  args: {
    companyId: v.optional(v.id("companies")),
    search: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    if (args.search) {
      return await ctx.db
        .query("contacts")
        .withSearchIndex("search_contacts", (q) => {
          let searchQuery = q.search("firstName", args.search!).eq("userId", userId);
          if (args.companyId) {
            searchQuery = searchQuery.eq("companyId", args.companyId);
          }
          return searchQuery;
        })
        .take(50);
    }

    let query = ctx.db
      .query("contacts")
      .withIndex("by_user", (q) => q.eq("userId", userId));

    if (args.companyId) {
      query = ctx.db
        .query("contacts")
        .withIndex("by_company", (q) => q.eq("companyId", args.companyId!));
    }

    return await query.order("desc").take(50);
  },
});

export const createContact = mutation({
  args: {
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    title: v.optional(v.string()),
    department: v.optional(v.string()),
    linkedinUrl: v.optional(v.string()),
    companyId: v.id("companies"),
    isPrimary: v.optional(v.boolean()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Verify company belongs to user
    const company = await ctx.db.get(args.companyId);
    if (!company || company.userId !== userId) {
      throw new Error("Company not found or unauthorized");
    }

    return await ctx.db.insert("contacts", {
      ...args,
      userId,
    });
  },
});

export const updateContact = mutation({
  args: {
    contactId: v.id("contacts"),
    updates: v.object({
      firstName: v.optional(v.string()),
      lastName: v.optional(v.string()),
      email: v.optional(v.string()),
      phone: v.optional(v.string()),
      title: v.optional(v.string()),
      department: v.optional(v.string()),
      linkedinUrl: v.optional(v.string()),
      isPrimary: v.optional(v.boolean()),
      notes: v.optional(v.string()),
    }),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const contact = await ctx.db.get(args.contactId);
    if (!contact || contact.userId !== userId) {
      throw new Error("Contact not found or unauthorized");
    }

    await ctx.db.patch(args.contactId, args.updates);
  },
});

export const deleteContact = mutation({
  args: {
    contactId: v.id("contacts"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const contact = await ctx.db.get(args.contactId);
    if (!contact || contact.userId !== userId) {
      throw new Error("Contact not found or unauthorized");
    }

    await ctx.db.delete(args.contactId);
  },
});
