import { v } from "convex/values";
import { query, mutation, action, internalMutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api, internal } from "./_generated/api";
import { Id } from "./_generated/dataModel";

export const listCompanies = query({
  args: {
    search: v.optional(v.string()),
    industry: v.optional(v.string()),
    status: v.optional(v.string()),
    minLeadScore: v.optional(v.number()),
    limit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    let query = ctx.db
      .query("companies")
      .withIndex("by_user", (q) => q.eq("userId", userId));

    if (args.search) {
      return await ctx.db
        .query("companies")
        .withSearchIndex("search_companies", (q) => {
          let searchQuery = q.search("name", args.search!);
          if (args.industry) {
            searchQuery = searchQuery.eq("industry", args.industry);
          }
          if (args.status) {
            searchQuery = searchQuery.eq("status", args.status as any);
          }
          return searchQuery.eq("userId", userId);
        })
        .take(args.limit || 50);
    }

    if (args.status) {
      query = ctx.db
        .query("companies")
        .withIndex("by_status", (q) => q.eq("userId", userId).eq("status", args.status as any));
    }

    let results = await query.order("desc").take(args.limit || 50);

    if (args.minLeadScore) {
      results = results.filter(c => (c.leadScore || 0) >= args.minLeadScore!);
    }

    return results;
  },
});

export const getCompanyStats = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const companies = await ctx.db
      .query("companies")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    const totalCompanies = companies.length;
    const highQualityLeads = companies.filter(c => (c.leadScore || 0) >= 80).length;
    const industries = [...new Set(companies.map(c => c.industry).filter(Boolean))];
    
    const statusCounts = companies.reduce((acc, company) => {
      const status = company.status || "new";
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const recentlyAdded = companies.filter(c => 
      c.enrichedAt > Date.now() - 7 * 24 * 60 * 60 * 1000
    ).length;

    return {
      totalCompanies,
      highQualityLeads,
      industriesCount: industries.length,
      averageLeadScore: totalCompanies > 0 
        ? Math.round(companies.reduce((sum, c) => sum + (c.leadScore || 0), 0) / totalCompanies)
        : 0,
      statusCounts,
      recentlyAdded,
      conversionRate: totalCompanies > 0 
        ? Math.round(((statusCounts["closed-won"] || 0) / totalCompanies) * 100)
        : 0,
    };
  },
});

export const getCompanyById = query({
  args: { companyId: v.id("companies") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const company = await ctx.db.get(args.companyId);
    if (!company || company.userId !== userId) {
      return null;
    }

    return company;
  },
});

export const updateCompany = mutation({
  args: {
    companyId: v.id("companies"),
    updates: v.object({
      status: v.optional(v.union(
        v.literal("new"),
        v.literal("contacted"),
        v.literal("qualified"),
        v.literal("proposal"),
        v.literal("closed-won"),
        v.literal("closed-lost")
      )),
      tags: v.optional(v.array(v.string())),
      notes: v.optional(v.string()),
      nextFollowUp: v.optional(v.number()),
      contactInfo: v.optional(v.object({
        email: v.optional(v.string()),
        phone: v.optional(v.string()),
      })),
    }),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const company = await ctx.db.get(args.companyId);
    if (!company || company.userId !== userId) {
      throw new Error("Company not found or unauthorized");
    }

    await ctx.db.patch(args.companyId, {
      ...args.updates,
      lastContactDate: args.updates.status === "contacted" ? Date.now() : company.lastContactDate,
    });
  },
});

export const enrichCompany = action({
  args: {
    input: v.string(),
  },
  handler: async (ctx, args): Promise<{ success: boolean; companyId: string }> => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const requestId = await ctx.runMutation(internal.companies.createEnrichmentRequest, {
      input: args.input,
      userId,
    });

    try {
      const enrichedData = await enrichCompanyData(args.input);
      
      const companyId: string = await ctx.runMutation(internal.companies.saveEnrichedCompany, {
        ...enrichedData,
        userId,
      });

      await ctx.runMutation(internal.companies.updateEnrichmentRequest, {
        requestId,
        status: "completed",
        result: `Company saved with ID: ${companyId}`,
      });

      return { success: true, companyId };
    } catch (error) {
      await ctx.runMutation(internal.companies.updateEnrichmentRequest, {
        requestId,
        status: "failed",
        result: `Error: ${error}`,
      });
      throw error;
    }
  },
});

export const bulkEnrichCompanies = action({
  args: {
    inputs: v.array(v.string()),
  },
  handler: async (ctx, args): Promise<Array<{input: string; success: boolean; companyId?: string; error?: string}>> => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const results = [];
    for (const input of args.inputs) {
      try {
        const result: { success: boolean; companyId: string } = await ctx.runAction(api.companies.enrichCompany, { input });
        results.push({ input, success: true, companyId: result.companyId });
      } catch (error) {
        results.push({ input, success: false, error: String(error) });
      }
    }

    return results;
  },
});

export const createEnrichmentRequest = internalMutation({
  args: {
    input: v.string(),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("enrichmentRequests", {
      input: args.input,
      status: "pending",
      userId: args.userId,
    });
  },
});

export const updateEnrichmentRequest = internalMutation({
  args: {
    requestId: v.id("enrichmentRequests"),
    status: v.union(v.literal("completed"), v.literal("failed")),
    result: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.requestId, {
      status: args.status,
      result: args.result,
    });
  },
});

export const saveEnrichedCompany = internalMutation({
  args: {
    name: v.string(),
    domain: v.optional(v.string()),
    industry: v.optional(v.string()),
    size: v.optional(v.string()),
    location: v.optional(v.string()),
    description: v.optional(v.string()),
    linkedinUrl: v.optional(v.string()),
    website: v.optional(v.string()),
    founded: v.optional(v.string()),
    specialties: v.optional(v.array(v.string())),
    leadScore: v.optional(v.number()),
    revenue: v.optional(v.string()),
    employees: v.optional(v.number()),
    technologies: v.optional(v.array(v.string())),
    socialMedia: v.optional(v.object({
      twitter: v.optional(v.string()),
      facebook: v.optional(v.string()),
      instagram: v.optional(v.string()),
    })),
    contactInfo: v.optional(v.object({
      email: v.optional(v.string()),
      phone: v.optional(v.string()),
    })),
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("companies")
      .withIndex("by_domain", (q) => q.eq("domain", args.domain || ""))
      .filter((q) => q.eq(q.field("userId"), args.userId))
      .first();

    if (existing && args.domain) {
      await ctx.db.patch(existing._id, {
        ...args,
        enrichedAt: Date.now(),
      });
      return existing._id;
    }

    return await ctx.db.insert("companies", {
      ...args,
      enrichedAt: Date.now(),
      status: "new",
      tags: [],
    });
  },
});

export const deleteCompany = mutation({
  args: {
    companyId: v.id("companies"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const company = await ctx.db.get(args.companyId);
    if (!company || company.userId !== userId) {
      throw new Error("Company not found or unauthorized");
    }

    // Delete related contacts and activities
    const contacts = await ctx.db
      .query("contacts")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();

    for (const contact of contacts) {
      await ctx.db.delete(contact._id);
    }

    const activities = await ctx.db
      .query("activities")
      .withIndex("by_company", (q) => q.eq("companyId", args.companyId))
      .collect();

    for (const activity of activities) {
      await ctx.db.delete(activity._id);
    }

    await ctx.db.delete(args.companyId);
  },
});

// Enhanced company enrichment function
async function enrichCompanyData(input: string) {
  const isUrl = input.includes('.') && !input.includes(' ');
  const domain = isUrl ? input.replace(/^https?:\/\//, '').replace(/\/$/, '') : undefined;
  
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  const mockData = {
    name: isUrl ? domain?.split('.')[0] || input : input,
    domain: domain,
    industry: getRandomIndustry(),
    size: getRandomCompanySize(),
    location: getRandomLocation(),
    description: `${input} is a leading company in their industry, providing innovative solutions to their customers with cutting-edge technology and exceptional service.`,
    linkedinUrl: `https://linkedin.com/company/${input.toLowerCase().replace(/\s+/g, '-')}`,
    website: domain ? `https://${domain}` : undefined,
    founded: getRandomYear(),
    specialties: getRandomSpecialties(),
    leadScore: Math.floor(Math.random() * 40) + 60,
    revenue: getRandomRevenue(),
    employees: getRandomEmployeeCount(),
    technologies: getRandomTechnologies(),
    socialMedia: {
      twitter: `https://twitter.com/${input.toLowerCase().replace(/\s+/g, '')}`,
      facebook: `https://facebook.com/${input.toLowerCase().replace(/\s+/g, '')}`,
      instagram: `https://instagram.com/${input.toLowerCase().replace(/\s+/g, '')}`,
    },
    contactInfo: {
      email: `info@${domain || input.toLowerCase().replace(/\s+/g, '')}.com`,
      phone: generateRandomPhone(),
    },
  };
  
  return mockData;
}

function getRandomIndustry() {
  const industries = [
    "Technology", "Healthcare", "Finance", "E-commerce", "SaaS", 
    "Manufacturing", "Education", "Real Estate", "Marketing", "Consulting",
    "Fintech", "Biotech", "Cybersecurity", "AI/ML", "Blockchain"
  ];
  return industries[Math.floor(Math.random() * industries.length)];
}

function getRandomCompanySize() {
  const sizes = ["1-10", "11-50", "51-200", "201-500", "501-1000", "1000+"];
  return sizes[Math.floor(Math.random() * sizes.length)];
}

function getRandomLocation() {
  const locations = [
    "San Francisco, CA", "New York, NY", "Austin, TX", "Seattle, WA",
    "Boston, MA", "Chicago, IL", "Los Angeles, CA", "Denver, CO",
    "Miami, FL", "Atlanta, GA", "Portland, OR", "Nashville, TN"
  ];
  return locations[Math.floor(Math.random() * locations.length)];
}

function getRandomYear() {
  const currentYear = new Date().getFullYear();
  return String(currentYear - Math.floor(Math.random() * 30));
}

function getRandomSpecialties() {
  const allSpecialties = [
    "Software Development", "Cloud Computing", "AI/ML", "Data Analytics",
    "Digital Marketing", "E-commerce", "Mobile Apps", "Cybersecurity",
    "Consulting", "Customer Support", "Sales", "Product Management",
    "DevOps", "UI/UX Design", "API Development", "Automation"
  ];
  const count = Math.floor(Math.random() * 4) + 2;
  return allSpecialties.sort(() => 0.5 - Math.random()).slice(0, count);
}

function getRandomRevenue() {
  const revenues = [
    "$1M - $5M", "$5M - $10M", "$10M - $50M", "$50M - $100M", 
    "$100M - $500M", "$500M - $1B", "$1B+"
  ];
  return revenues[Math.floor(Math.random() * revenues.length)];
}

function getRandomEmployeeCount() {
  return Math.floor(Math.random() * 5000) + 10;
}

function getRandomTechnologies() {
  const techs = [
    "React", "Node.js", "Python", "AWS", "Docker", "Kubernetes",
    "MongoDB", "PostgreSQL", "Redis", "GraphQL", "TypeScript",
    "Salesforce", "HubSpot", "Slack", "Zoom", "Microsoft 365"
  ];
  const count = Math.floor(Math.random() * 6) + 3;
  return techs.sort(() => 0.5 - Math.random()).slice(0, count);
}

function generateRandomPhone() {
  const areaCode = Math.floor(Math.random() * 900) + 100;
  const exchange = Math.floor(Math.random() * 900) + 100;
  const number = Math.floor(Math.random() * 9000) + 1000;
  return `+1 (${areaCode}) ${exchange}-${number}`;
}
