import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { Dashboard } from "./Dashboard";
import { useState } from "react";

export default function App() {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="sticky top-0 z-10 bg-white/95 backdrop-blur-sm border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-8">
              <h2 className="text-xl font-bold text-blue-600">LeadEnrich Pro</h2>
              <Authenticated>
                <nav className="hidden md:flex space-x-6">
                  <button
                    onClick={() => setActiveTab("dashboard")}
                    className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === "dashboard"
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Dashboard
                  </button>
                  <button
                    onClick={() => setActiveTab("companies")}
                    className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === "companies"
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Companies
                  </button>
                  <button
                    onClick={() => setActiveTab("activities")}
                    className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === "activities"
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Activities
                  </button>
                  <button
                    onClick={() => setActiveTab("lists")}
                    className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === "lists"
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Lists
                  </button>
                  <button
                    onClick={() => setActiveTab("templates")}
                    className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === "templates"
                        ? "bg-blue-100 text-blue-700"
                        : "text-gray-600 hover:text-gray-900"
                    }`}
                  >
                    Templates
                  </button>
                </nav>
              </Authenticated>
            </div>
            <Authenticated>
              <SignOutButton />
            </Authenticated>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <Content activeTab={activeTab} setActiveTab={setActiveTab} />
      </main>
      <Toaster position="top-right" />
    </div>
  );
}

function Content({ activeTab, setActiveTab }: { activeTab: string; setActiveTab: (tab: string) => void }) {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <Authenticated>
        <Dashboard activeTab={activeTab} setActiveTab={setActiveTab} />
      </Authenticated>

      <Unauthenticated>
        <div className="flex flex-col items-center justify-center min-h-[80vh] gap-8">
          <div className="text-center max-w-4xl">
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              LeadEnrich Pro
            </h1>
            <p className="text-xl text-gray-600 mb-12">
              The ultimate B2B lead generation and company enrichment platform for sales professionals
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <div className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Company Enrichment</h3>
                <p className="text-gray-600 text-sm">
                  Transform basic company info into detailed business profiles with AI-powered insights
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Lead Scoring</h3>
                <p className="text-gray-600 text-sm">
                  AI-powered qualification scores and analytics for better targeting and conversion
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Activity Tracking</h3>
                <p className="text-gray-600 text-sm">
                  Comprehensive activity management with automated follow-ups and reminders
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm border hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Email Templates</h3>
                <p className="text-gray-600 text-sm">
                  Professional email templates for outreach, follow-ups, and proposals
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Everything you need to accelerate your B2B sales
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">🎯 Smart Targeting</h4>
                  <p className="text-gray-600 text-sm">Advanced filtering and search capabilities to find your ideal prospects</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">📊 Real-time Analytics</h4>
                  <p className="text-gray-600 text-sm">Track performance metrics and optimize your outreach strategies</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">🔄 Workflow Automation</h4>
                  <p className="text-gray-600 text-sm">Streamline repetitive tasks and focus on closing deals</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="w-full max-w-md">
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">
                Get Started Today
              </h3>
              <SignInForm />
            </div>
          </div>
        </div>
      </Unauthenticated>
    </div>
  );
}
