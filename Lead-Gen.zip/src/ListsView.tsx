import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../convex/_generated/dataModel";

export function ListsView() {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedList, setSelectedList] = useState<Id<"lists"> | null>(null);
  const [newList, setNewList] = useState({
    name: "",
    description: "",
    tags: "",
    isPublic: false
  });

  const lists = useQuery(api.lists.listLists);
  const companies = useQuery(api.companies.listCompanies, { limit: 1000 });
  
  const createList = useMutation(api.lists.createList);
  const updateList = useMutation(api.lists.updateList);
  const deleteList = useMutation(api.lists.deleteList);
  const addCompaniesToList = useMutation(api.lists.addCompaniesToList);
  const removeCompaniesFromList = useMutation(api.lists.removeCompaniesFromList);

  const handleCreateList = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createList({
        name: newList.name,
        description: newList.description || undefined,
        companyIds: [],
        tags: newList.tags ? newList.tags.split(",").map(t => t.trim()) : undefined,
        isPublic: newList.isPublic
      });
      
      setNewList({
        name: "",
        description: "",
        tags: "",
        isPublic: false
      });
      setShowCreateForm(false);
      toast.success("List created successfully");
    } catch (error) {
      toast.error("Failed to create list");
    }
  };

  const handleDeleteList = async (listId: Id<"lists">) => {
    try {
      await deleteList({ listId });
      toast.success("List deleted");
    } catch (error) {
      toast.error("Failed to delete list");
    }
  };

  const selectedListData = lists?.find(l => l._id === selectedList);
  const selectedListCompanies = selectedListData ? 
    companies?.filter(c => selectedListData.companyIds.includes(c._id)) || [] : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Company Lists</h1>
        <button
          onClick={() => setShowCreateForm(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          New List
        </button>
      </div>

      {/* Create List Form */}
      {showCreateForm && (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Create New List</h2>
          <form onSubmit={handleCreateList} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="List Name"
                value={newList.name}
                onChange={(e) => setNewList({...newList, name: e.target.value})}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
              <input
                type="text"
                placeholder="Tags (comma separated)"
                value={newList.tags}
                onChange={(e) => setNewList({...newList, tags: e.target.value})}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <textarea
              placeholder="Description (optional)"
              value={newList.description}
              onChange={(e) => setNewList({...newList, description: e.target.value})}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={3}
            />
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="isPublic"
                checked={newList.isPublic}
                onChange={(e) => setNewList({...newList, isPublic: e.target.checked})}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <label htmlFor="isPublic" className="text-sm text-gray-700">
                Make this list public
              </label>
            </div>
            <div className="flex gap-3">
              <button
                type="submit"
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Create List
              </button>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Lists Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="p-6 border-b">
              <h2 className="text-lg font-semibold text-gray-900">
                Your Lists ({lists?.length || 0})
              </h2>
            </div>
            <div className="divide-y divide-gray-200">
              {lists?.map((list) => (
                <div
                  key={list._id}
                  className={`p-4 cursor-pointer hover:bg-gray-50 ${
                    selectedList === list._id ? "bg-blue-50 border-r-2 border-blue-500" : ""
                  }`}
                  onClick={() => setSelectedList(list._id)}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{list.name}</h3>
                      {list.description && (
                        <p className="text-sm text-gray-600 mt-1">{list.description}</p>
                      )}
                      <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                        <span>{list.companyIds.length} companies</span>
                        {list.isPublic && (
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded">
                            Public
                          </span>
                        )}
                      </div>
                      {list.tags && list.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {list.tags.map((tag, index) => (
                            <span
                              key={index}
                              className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteList(list._id);
                      }}
                      className="p-1 text-red-600 hover:text-red-800"
                      title="Delete List"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
              
              {lists?.length === 0 && (
                <div className="p-8 text-center">
                  <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
                  </svg>
                  <h3 className="mt-2 text-sm font-medium text-gray-900">No lists yet</h3>
                  <p className="mt-1 text-sm text-gray-500">Create your first company list to get started.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* List Details Panel */}
        <div className="lg:col-span-2">
          {selectedListData ? (
            <ListDetailsPanel
              list={selectedListData}
              companies={selectedListCompanies}
              allCompanies={companies || []}
              onAddCompanies={addCompaniesToList}
              onRemoveCompanies={removeCompaniesFromList}
            />
          ) : (
            <div className="bg-white rounded-lg shadow-sm border p-12 text-center">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
              </svg>
              <h3 className="mt-2 text-lg font-medium text-gray-900">Select a list</h3>
              <p className="mt-1 text-sm text-gray-500">Choose a list from the left panel to view and manage its companies.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ListDetailsPanel({ list, companies, allCompanies, onAddCompanies, onRemoveCompanies }: any) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCompanies, setSelectedCompanies] = useState<Set<Id<"companies">>>(new Set());
  const [searchTerm, setSearchTerm] = useState("");

  const availableCompanies = allCompanies.filter((c: any) => 
    !list.companyIds.includes(c._id) &&
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddSelected = async () => {
    if (selectedCompanies.size === 0) return;
    
    try {
      await onAddCompanies({
        listId: list._id,
        companyIds: Array.from(selectedCompanies)
      });
      setSelectedCompanies(new Set());
      setShowAddModal(false);
      toast.success(`Added ${selectedCompanies.size} companies to list`);
    } catch (error) {
      toast.error("Failed to add companies");
    }
  };

  const handleRemoveCompany = async (companyId: Id<"companies">) => {
    try {
      await onRemoveCompanies({
        listId: list._id,
        companyIds: [companyId]
      });
      toast.success("Company removed from list");
    } catch (error) {
      toast.error("Failed to remove company");
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border">
      <div className="p-6 border-b">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-gray-900">{list.name}</h2>
            {list.description && (
              <p className="text-gray-600 mt-1">{list.description}</p>
            )}
            <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
              <span>{companies.length} companies</span>
              {list.isPublic && (
                <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">
                  Public
                </span>
              )}
            </div>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            Add Companies
          </button>
        </div>
      </div>

      <div className="p-6">
        <div className="space-y-4">
          {companies.map((company: any) => (
            <div key={company._id} className="flex justify-between items-center p-4 border border-gray-200 rounded-lg">
              <div>
                <h3 className="font-medium text-gray-900">{company.name}</h3>
                <div className="flex items-center gap-4 text-sm text-gray-500 mt-1">
                  {company.industry && <span>{company.industry}</span>}
                  {company.location && <span>{company.location}</span>}
                  {company.leadScore && (
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      company.leadScore >= 80 ? "bg-green-100 text-green-800" :
                      company.leadScore >= 60 ? "bg-yellow-100 text-yellow-800" :
                      "bg-red-100 text-red-800"
                    }`}>
                      Score: {company.leadScore}
                    </span>
                  )}
                </div>
              </div>
              <button
                onClick={() => handleRemoveCompany(company._id)}
                className="p-2 text-red-600 hover:text-red-800"
                title="Remove from list"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          ))}
          
          {companies.length === 0 && (
            <div className="text-center py-12">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <h3 className="mt-2 text-sm font-medium text-gray-900">No companies in this list</h3>
              <p className="mt-1 text-sm text-gray-500">Add companies to get started.</p>
            </div>
          )}
        </div>
      </div>

      {/* Add Companies Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-hidden">
            <div className="flex justify-between items-center p-6 border-b">
              <h3 className="text-lg font-semibold text-gray-900">Add Companies to List</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="p-6">
              <input
                type="text"
                placeholder="Search companies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent mb-4"
              />
              
              <div className="max-h-96 overflow-y-auto space-y-2">
                {availableCompanies.map((company: any) => (
                  <div key={company._id} className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg">
                    <input
                      type="checkbox"
                      checked={selectedCompanies.has(company._id)}
                      onChange={(e) => {
                        const newSelected = new Set(selectedCompanies);
                        if (e.target.checked) {
                          newSelected.add(company._id);
                        } else {
                          newSelected.delete(company._id);
                        }
                        setSelectedCompanies(newSelected);
                      }}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{company.name}</h4>
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        {company.industry && <span>{company.industry}</span>}
                        {company.location && <span>• {company.location}</span>}
                      </div>
                    </div>
                  </div>
                ))}
                
                {availableCompanies.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    {searchTerm ? "No companies found matching your search" : "All companies are already in this list"}
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex justify-between items-center p-6 border-t bg-gray-50">
              <span className="text-sm text-gray-600">
                {selectedCompanies.size} companies selected
              </span>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddSelected}
                  disabled={selectedCompanies.size === 0}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Add Selected
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
