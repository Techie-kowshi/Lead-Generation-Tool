import { useState } from "react";
import { useMutation, useQuery, useAction } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../convex/_generated/dataModel";

export function LeadEnrichmentTool() {
  const [input, setInput] = useState("");
  const [isEnriching, setIsEnriching] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  
  const companies = useQuery(api.companies.listCompanies, { 
    search: searchTerm || undefined 
  });
  const stats = useQuery(api.companies.getCompanyStats);
  const enrichCompany = useAction(api.companies.enrichCompany);
  const deleteCompany = useMutation(api.companies.deleteCompany);

  const handleEnrich = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setIsEnriching(true);
    try {
      await enrichCompany({ input: input.trim() });
      toast.success("Company enriched successfully!");
      setInput("");
    } catch (error) {
      toast.error("Failed to enrich company");
      console.error(error);
    } finally {
      setIsEnriching(false);
    }
  };

  const handleDelete = async (companyId: Id<"companies">) => {
    try {
      await deleteCompany({ companyId });
      toast.success("Company deleted");
    } catch (error) {
      toast.error("Failed to delete company");
    }
  };

  const getLeadScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600 bg-green-50";
    if (score >= 60) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  return (
    <div className="space-y-6">
      {/* Stats Dashboard */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="text-sm font-medium text-gray-500">Total Companies</h3>
            <p className="text-2xl font-bold text-gray-900">{stats.totalCompanies}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="text-sm font-medium text-gray-500">High Quality Leads</h3>
            <p className="text-2xl font-bold text-green-600">{stats.highQualityLeads}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="text-sm font-medium text-gray-500">Industries</h3>
            <p className="text-2xl font-bold text-blue-600">{stats.industriesCount}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="text-sm font-medium text-gray-500">Avg Lead Score</h3>
            <p className="text-2xl font-bold text-purple-600">{stats.averageLeadScore}</p>
          </div>
        </div>
      )}

      {/* Enrichment Form */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Enrich Company Data
        </h2>
        <form onSubmit={handleEnrich} className="flex gap-4">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter company name or domain (e.g., 'Acme Corp' or 'acme.com')"
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={isEnriching}
          />
          <button
            type="submit"
            disabled={isEnriching || !input.trim()}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isEnriching ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                Enriching...
              </>
            ) : (
              "Enrich"
            )}
          </button>
        </form>
        <p className="text-sm text-gray-500 mt-2">
          Enter a company name or website domain to get detailed business information and lead scoring.
        </p>
      </div>

      {/* Search and Filter */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-900">
            Enriched Companies ({companies?.length || 0})
          </h2>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search companies..."
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
          />
        </div>

        {/* Companies List */}
        <div className="space-y-4">
          {companies?.map((company) => (
            <div key={company._id} className="border border-gray-200 rounded-lg p-4 hover:shadow-sm transition-shadow">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{company.name}</h3>
                  {company.domain && (
                    <a 
                      href={company.website || `https://${company.domain}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-sm"
                    >
                      {company.domain}
                    </a>
                  )}
                </div>
                <div className="flex items-center gap-3">
                  {company.leadScore && (
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getLeadScoreColor(company.leadScore)}`}>
                      Score: {company.leadScore}
                    </span>
                  )}
                  <button
                    onClick={() => handleDelete(company._id)}
                    className="text-red-600 hover:text-red-800 text-sm"
                  >
                    Delete
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Industry:</span>
                  <span className="ml-2 text-gray-600">{company.industry || "N/A"}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Size:</span>
                  <span className="ml-2 text-gray-600">{company.size || "N/A"}</span>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Location:</span>
                  <span className="ml-2 text-gray-600">{company.location || "N/A"}</span>
                </div>
              </div>
              
              {company.description && (
                <p className="text-gray-600 text-sm mt-3">{company.description}</p>
              )}
              
              {company.specialties && company.specialties.length > 0 && (
                <div className="mt-3">
                  <span className="font-medium text-gray-700 text-sm">Specialties:</span>
                  <div className="flex flex-wrap gap-2 mt-1">
                    {company.specialties.map((specialty, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="flex justify-between items-center mt-3 pt-3 border-t border-gray-100">
                <div className="text-xs text-gray-500">
                  Enriched: {new Date(company.enrichedAt).toLocaleDateString()}
                </div>
                <div className="flex gap-2">
                  {company.linkedinUrl && (
                    <a
                      href={company.linkedinUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-xs"
                    >
                      LinkedIn
                    </a>
                  )}
                  {company.website && (
                    <a
                      href={company.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-xs"
                    >
                      Website
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
          
          {companies?.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No companies found. Start by enriching your first company above.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
