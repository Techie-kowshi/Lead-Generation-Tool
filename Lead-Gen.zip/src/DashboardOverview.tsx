import { useQuery } from "convex/react";
import { api } from "../convex/_generated/api";

interface DashboardOverviewProps {
  setActiveTab: (tab: string) => void;
}

export function DashboardOverview({ setActiveTab }: DashboardOverviewProps) {
  const stats = useQuery(api.companies.getCompanyStats);
  const upcomingActivities = useQuery(api.activities.getUpcomingActivities);
  const recentCompanies = useQuery(api.companies.listCompanies, { limit: 5 });

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome to LeadEnrich Pro</h1>
        <p className="text-blue-100 text-lg">
          Your comprehensive B2B lead generation and company enrichment platform
        </p>
      </div>

      {/* Key Metrics */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Companies</p>
                <p className="text-3xl font-bold text-gray-900">{stats.totalCompanies}</p>
              </div>
              <div className="p-3 bg-blue-100 rounded-full">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
            </div>
            <div className="mt-4">
              <span className="text-green-600 text-sm font-medium">
                +{stats.recentlyAdded} this week
              </span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">High Quality Leads</p>
                <p className="text-3xl font-bold text-green-600">{stats.highQualityLeads}</p>
              </div>
              <div className="p-3 bg-green-100 rounded-full">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
              </div>
            </div>
            <div className="mt-4">
              <span className="text-gray-600 text-sm">
                Score ≥ 80
              </span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Industries</p>
                <p className="text-3xl font-bold text-purple-600">{stats.industriesCount}</p>
              </div>
              <div className="p-3 bg-purple-100 rounded-full">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2-2v2m8 0V6a2 2 0 012 2v6a2 2 0 01-2 2H6a2 2 0 01-2-2V8a2 2 0 012-2V6" />
                </svg>
              </div>
            </div>
            <div className="mt-4">
              <span className="text-gray-600 text-sm">
                Diversified portfolio
              </span>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                <p className="text-3xl font-bold text-orange-600">{stats.conversionRate}%</p>
              </div>
              <div className="p-3 bg-orange-100 rounded-full">
                <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
              </div>
            </div>
            <div className="mt-4">
              <span className="text-gray-600 text-sm">
                Closed won deals
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            onClick={() => setActiveTab("companies")}
            className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors group"
          >
            <div className="text-center">
              <svg className="w-8 h-8 text-gray-400 group-hover:text-blue-500 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              <p className="text-sm font-medium text-gray-900">Enrich Companies</p>
              <p className="text-xs text-gray-500">Add new leads to your pipeline</p>
            </div>
          </button>

          <button
            onClick={() => setActiveTab("activities")}
            className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-green-500 hover:bg-green-50 transition-colors group"
          >
            <div className="text-center">
              <svg className="w-8 h-8 text-gray-400 group-hover:text-green-500 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
              </svg>
              <p className="text-sm font-medium text-gray-900">Create Activity</p>
              <p className="text-xs text-gray-500">Schedule follow-ups and tasks</p>
            </div>
          </button>

          <button
            onClick={() => setActiveTab("lists")}
            className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-colors group"
          >
            <div className="text-center">
              <svg className="w-8 h-8 text-gray-400 group-hover:text-purple-500 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
              </svg>
              <p className="text-sm font-medium text-gray-900">Create List</p>
              <p className="text-xs text-gray-500">Organize companies into lists</p>
            </div>
          </button>

          <button
            onClick={() => setActiveTab("templates")}
            className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-orange-500 hover:bg-orange-50 transition-colors group"
          >
            <div className="text-center">
              <svg className="w-8 h-8 text-gray-400 group-hover:text-orange-500 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <p className="text-sm font-medium text-gray-900">Email Templates</p>
              <p className="text-xs text-gray-500">Create outreach templates</p>
            </div>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Activities */}
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Upcoming Activities</h2>
            <button
              onClick={() => setActiveTab("activities")}
              className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            >
              View all
            </button>
          </div>
          
          {upcomingActivities && upcomingActivities.length > 0 ? (
            <div className="space-y-3">
              {upcomingActivities.slice(0, 5).map((activity) => (
                <div key={activity._id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className={`p-2 rounded-full ${
                    activity.type === "email" ? "bg-blue-100 text-blue-600" :
                    activity.type === "call" ? "bg-green-100 text-green-600" :
                    activity.type === "meeting" ? "bg-purple-100 text-purple-600" :
                    activity.type === "task" ? "bg-orange-100 text-orange-600" :
                    "bg-gray-100 text-gray-600"
                  }`}>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 text-sm">{activity.subject}</p>
                    <p className="text-xs text-gray-500">
                      {activity.scheduledDate && new Date(activity.scheduledDate).toLocaleString()}
                    </p>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    activity.priority === "high" ? "bg-red-100 text-red-800" :
                    activity.priority === "medium" ? "bg-yellow-100 text-yellow-800" :
                    "bg-green-100 text-green-800"
                  }`}>
                    {activity.priority}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <h3 className="mt-2 text-sm font-medium text-gray-900">No upcoming activities</h3>
              <p className="mt-1 text-sm text-gray-500">Schedule your first activity to get started.</p>
            </div>
          )}
        </div>

        {/* Recent Companies */}
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recently Added Companies</h2>
            <button
              onClick={() => setActiveTab("companies")}
              className="text-blue-600 hover:text-blue-800 text-sm font-medium"
            >
              View all
            </button>
          </div>
          
          {recentCompanies && recentCompanies.length > 0 ? (
            <div className="space-y-3">
              {recentCompanies.map((company) => (
                <div key={company._id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900 text-sm">{company.name}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      {company.industry && <span>{company.industry}</span>}
                      {company.location && <span>• {company.location}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {company.leadScore && (
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        company.leadScore >= 80 ? "bg-green-100 text-green-800" :
                        company.leadScore >= 60 ? "bg-yellow-100 text-yellow-800" :
                        "bg-red-100 text-red-800"
                      }`}>
                        {company.leadScore}
                      </span>
                    )}
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      company.status === "new" ? "bg-gray-100 text-gray-800" :
                      company.status === "contacted" ? "bg-blue-100 text-blue-800" :
                      company.status === "qualified" ? "bg-yellow-100 text-yellow-800" :
                      company.status === "proposal" ? "bg-purple-100 text-purple-800" :
                      company.status === "closed-won" ? "bg-green-100 text-green-800" :
                      "bg-red-100 text-red-800"
                    }`}>
                      {company.status?.replace('-', ' ') || "New"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <h3 className="mt-2 text-sm font-medium text-gray-900">No companies yet</h3>
              <p className="mt-1 text-sm text-gray-500">Start by enriching your first company.</p>
            </div>
          )}
        </div>
      </div>

      {/* Pipeline Status */}
      {stats && (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Sales Pipeline</h2>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            {Object.entries(stats.statusCounts).map(([status, count]) => (
              <div key={status} className="text-center">
                <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center text-2xl font-bold ${
                  status === "new" ? "bg-gray-100 text-gray-800" :
                  status === "contacted" ? "bg-blue-100 text-blue-800" :
                  status === "qualified" ? "bg-yellow-100 text-yellow-800" :
                  status === "proposal" ? "bg-purple-100 text-purple-800" :
                  status === "closed-won" ? "bg-green-100 text-green-800" :
                  "bg-red-100 text-red-800"
                }`}>
                  {count}
                </div>
                <p className="text-sm font-medium text-gray-900 mt-2 capitalize">
                  {status.replace('-', ' ')}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Performance Insights */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg border">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">💡 Performance Insights</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-2">🎯 Top Performing Industry</h3>
            <p className="text-sm text-gray-600">
              {stats && stats.totalCompanies > 0 ? "Technology sector shows highest conversion rates" : "Enrich more companies to see insights"}
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-2">📈 Growth Opportunity</h3>
            <p className="text-sm text-gray-600">
              {stats && stats.highQualityLeads > 0 ? `${stats.highQualityLeads} high-quality leads ready for outreach` : "Focus on lead scoring to identify opportunities"}
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-2">⚡ Quick Win</h3>
            <p className="text-sm text-gray-600">
              {upcomingActivities && upcomingActivities.length > 0 ? "Complete pending activities to maintain momentum" : "Schedule follow-up activities for better engagement"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
