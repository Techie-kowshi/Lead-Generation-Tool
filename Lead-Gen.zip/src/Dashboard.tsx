import { useState } from "react";
import { LeadEnrichmentTool } from "./LeadEnrichmentTool";
import { CompaniesView } from "./CompaniesView";
import { ActivitiesView } from "./ActivitiesView";
import { ListsView } from "./ListsView";
import { TemplatesView } from "./TemplatesView";
import { DashboardOverview } from "./DashboardOverview";

interface DashboardProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function Dashboard({ activeTab, setActiveTab }: DashboardProps) {
  const renderActiveTab = () => {
    switch (activeTab) {
      case "dashboard":
        return <DashboardOverview setActiveTab={setActiveTab} />;
      case "companies":
        return <CompaniesView />;
      case "activities":
        return <ActivitiesView />;
      case "lists":
        return <ListsView />;
      case "templates":
        return <TemplatesView />;
      default:
        return <DashboardOverview setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Mobile Navigation */}
      <div className="md:hidden">
        <select
          value={activeTab}
          onChange={(e) => setActiveTab(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="dashboard">Dashboard</option>
          <option value="companies">Companies</option>
          <option value="activities">Activities</option>
          <option value="lists">Lists</option>
          <option value="templates">Templates</option>
        </select>
      </div>

      {renderActiveTab()}
    </div>
  );
}
