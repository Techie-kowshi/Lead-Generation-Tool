import { useState } from "react";
import { useQuery, useMutation, useAction } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../convex/_generated/dataModel";
import { CompanyDetailsModal } from "./CompanyDetailsModal";
import { BulkEnrichModal } from "./BulkEnrichModal";

export function CompaniesView() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedIndustry, setSelectedIndustry] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [minLeadScore, setMinLeadScore] = useState<number | undefined>();
  const [selectedCompany, setSelectedCompany] = useState<Id<"companies"> | null>(null);
  const [showBulkEnrich, setShowBulkEnrich] = useState(false);
  const [selectedCompanies, setSelectedCompanies] = useState<Set<Id<"companies">>>(new Set());

  const companies = useQuery(api.companies.listCompanies, {
    search: searchTerm || undefined,
    industry: selectedIndustry || undefined,
    status: selectedStatus || undefined,
    minLeadScore,
    limit: 100,
  });

  const updateCompany = useMutation(api.companies.updateCompany);
  const deleteCompany = useMutation(api.companies.deleteCompany);
  const bulkEnrich = useAction(api.companies.bulkEnrichCompanies);

  const industries = [...new Set(companies?.map(c => c.industry).filter(Boolean))];
  const statuses = ["new", "contacted", "qualified", "proposal", "closed-won", "closed-lost"];

  const handleStatusUpdate = async (companyId: Id<"companies">, status: string) => {
    try {
      await updateCompany({
        companyId,
        updates: { status: status as any }
      });
      toast.success("Status updated");
    } catch (error) {
      toast.error("Failed to update status");
    }
  };

  const handleBulkDelete = async () => {
    if (selectedCompanies.size === 0) return;
    
    try {
      for (const companyId of selectedCompanies) {
        await deleteCompany({ companyId });
      }
      setSelectedCompanies(new Set());
      toast.success(`Deleted ${selectedCompanies.size} companies`);
    } catch (error) {
      toast.error("Failed to delete companies");
    }
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case "new": return "bg-gray-100 text-gray-800";
      case "contacted": return "bg-blue-100 text-blue-800";
      case "qualified": return "bg-yellow-100 text-yellow-800";
      case "proposal": return "bg-purple-100 text-purple-800";
      case "closed-won": return "bg-green-100 text-green-800";
      case "closed-lost": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getLeadScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600 bg-green-50";
    if (score >= 60) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Companies</h1>
        <div className="flex gap-3">
          <button
            onClick={() => setShowBulkEnrich(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            Bulk Enrich
          </button>
          {selectedCompanies.size > 0 && (
            <button
              onClick={handleBulkDelete}
              className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
              Delete ({selectedCompanies.size})
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <input
            type="text"
            placeholder="Search companies..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <select
            value={selectedIndustry}
            onChange={(e) => setSelectedIndustry(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Industries</option>
            {industries.map(industry => (
              <option key={industry} value={industry}>{industry}</option>
            ))}
          </select>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Statuses</option>
            {statuses.map(status => (
              <option key={status} value={status}>
                {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
              </option>
            ))}
          </select>
          <input
            type="number"
            placeholder="Min Lead Score"
            value={minLeadScore || ""}
            onChange={(e) => setMinLeadScore(e.target.value ? Number(e.target.value) : undefined)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            min="0"
            max="100"
          />
          <button
            onClick={() => {
              setSearchTerm("");
              setSelectedIndustry("");
              setSelectedStatus("");
              setMinLeadScore(undefined);
            }}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-700"
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Companies Table */}
      <div className="bg-white rounded-lg shadow-sm border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  <input
                    type="checkbox"
                    checked={(companies?.length || 0) > 0 && selectedCompanies.size === (companies?.length || 0)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedCompanies(new Set(companies?.map(c => c._id) || []));
                      } else {
                        setSelectedCompanies(new Set());
                      }
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Company
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Industry
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Lead Score
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Location
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {companies?.map((company) => (
                <tr key={company._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <input
                      type="checkbox"
                      checked={selectedCompanies.has(company._id)}
                      onChange={(e) => {
                        const newSelected = new Set(selectedCompanies);
                        if (e.target.checked) {
                          newSelected.add(company._id);
                        } else {
                          newSelected.delete(company._id);
                        }
                        setSelectedCompanies(newSelected);
                      }}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{company.name}</div>
                      {company.domain && (
                        <div className="text-sm text-gray-500">{company.domain}</div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-sm text-gray-900">{company.industry || "N/A"}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {company.leadScore && (
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getLeadScoreColor(company.leadScore)}`}>
                        {company.leadScore}
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={company.status || "new"}
                      onChange={(e) => handleStatusUpdate(company._id, e.target.value)}
                      className={`text-xs font-semibold px-2 py-1 rounded-full border-0 ${getStatusColor(company.status)}`}
                    >
                      {statuses.map(status => (
                        <option key={status} value={status}>
                          {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {company.location || "N/A"}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => setSelectedCompany(company._id)}
                      className="text-blue-600 hover:text-blue-900 mr-3"
                    >
                      View
                    </button>
                    <button
                      onClick={() => deleteCompany({ companyId: company._id })}
                      className="text-red-600 hover:text-red-900"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {companies?.length === 0 && (
          <div className="text-center py-12">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No companies found</h3>
            <p className="mt-1 text-sm text-gray-500">Get started by enriching your first company.</p>
          </div>
        )}
      </div>

      {/* Modals */}
      {selectedCompany && (
        <CompanyDetailsModal
          companyId={selectedCompany}
          onClose={() => setSelectedCompany(null)}
        />
      )}

      {showBulkEnrich && (
        <BulkEnrichModal
          onClose={() => setShowBulkEnrich(false)}
        />
      )}
    </div>
  );
}
