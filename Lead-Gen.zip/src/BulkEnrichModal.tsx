import { useState } from "react";
import { useAction } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";

interface BulkEnrichModalProps {
  onClose: () => void;
}

export function BulkEnrichModal({ onClose }: BulkEnrichModalProps) {
  const [inputText, setInputText] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<any[]>([]);

  const bulkEnrich = useAction(api.companies.bulkEnrichCompanies);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const inputs = inputText
      .split('\n')
      .map(line => line.trim())
      .filter(line => line.length > 0);

    if (inputs.length === 0) {
      toast.error("Please enter at least one company name or domain");
      return;
    }

    if (inputs.length > 50) {
      toast.error("Maximum 50 companies allowed per batch");
      return;
    }

    setIsProcessing(true);
    try {
      const enrichResults = await bulkEnrich({ inputs });
      setResults(enrichResults);
      
      const successful = enrichResults.filter(r => r.success).length;
      const failed = enrichResults.filter(r => !r.success).length;
      
      toast.success(`Enriched ${successful} companies successfully${failed > 0 ? `, ${failed} failed` : ''}`);
    } catch (error) {
      toast.error("Failed to process bulk enrichment");
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClear = () => {
    setInputText("");
    setResults([]);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-900">Bulk Company Enrichment</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {results.length === 0 ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Company Names or Domains
                </label>
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={`Enter company names or domains, one per line:

Example:
Acme Corp
example.com
Another Company
startup.io
Tech Solutions Inc`}
                  className="w-full h-64 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  disabled={isProcessing}
                />
                <p className="text-sm text-gray-500 mt-2">
                  Maximum 50 companies per batch. Each line should contain one company name or domain.
                </p>
              </div>

              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={handleClear}
                  className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                  disabled={isProcessing}
                >
                  Clear
                </button>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                    disabled={isProcessing}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isProcessing || !inputText.trim()}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        Processing...
                      </>
                    ) : (
                      "Start Enrichment"
                    )}
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Enrichment Results</h3>
                <div className="flex gap-2">
                  <button
                    onClick={() => setResults([])}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    New Batch
                  </button>
                  <button
                    onClick={onClose}
                    className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                  >
                    Close
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-800">Successful</h4>
                  <p className="text-2xl font-bold text-green-600">
                    {results.filter(r => r.success).length}
                  </p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-red-800">Failed</h4>
                  <p className="text-2xl font-bold text-red-600">
                    {results.filter(r => !r.success).length}
                  </p>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800">Total</h4>
                  <p className="text-2xl font-bold text-blue-600">{results.length}</p>
                </div>
              </div>

              <div className="space-y-3">
                {results.map((result, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg border ${
                      result.success
                        ? "border-green-200 bg-green-50"
                        : "border-red-200 bg-red-50"
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="font-medium">{result.input}</span>
                        {result.success ? (
                          <span className="ml-2 text-green-600 text-sm">✓ Enriched successfully</span>
                        ) : (
                          <span className="ml-2 text-red-600 text-sm">✗ Failed</span>
                        )}
                      </div>
                      <div className="text-sm text-gray-500">
                        {result.success ? (
                          <span>Company ID: {result.companyId}</span>
                        ) : (
                          <span>Error: {result.error}</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
