import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../convex/_generated/dataModel";

export function ActivitiesView() {
  const [selectedStatus, setSelectedStatus] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newActivity, setNewActivity] = useState({
    type: "note",
    subject: "",
    description: "",
    scheduledDate: "",
    priority: "medium",
    companyId: ""
  });

  const activities = useQuery(api.activities.listActivities, {
    status: (selectedStatus as any) || undefined,
    limit: 100
  });
  const upcomingActivities = useQuery(api.activities.getUpcomingActivities);
  const companies = useQuery(api.companies.listCompanies, { limit: 1000 });

  const createActivity = useMutation(api.activities.createActivity);
  const completeActivity = useMutation(api.activities.completeActivity);
  const deleteActivity = useMutation(api.activities.deleteActivity);

  const handleCreateActivity = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createActivity({
        type: newActivity.type as any,
        subject: newActivity.subject,
        description: newActivity.description || undefined,
        companyId: newActivity.companyId ? newActivity.companyId as Id<"companies"> : undefined,
        scheduledDate: newActivity.scheduledDate ? new Date(newActivity.scheduledDate).getTime() : undefined,
        priority: newActivity.priority as any
      });
      
      setNewActivity({
        type: "note",
        subject: "",
        description: "",
        scheduledDate: "",
        priority: "medium",
        companyId: ""
      });
      setShowCreateForm(false);
      toast.success("Activity created successfully");
    } catch (error) {
      toast.error("Failed to create activity");
    }
  };

  const handleCompleteActivity = async (activityId: Id<"activities">) => {
    try {
      await completeActivity({ activityId });
      toast.success("Activity completed");
    } catch (error) {
      toast.error("Failed to complete activity");
    }
  };

  const handleDeleteActivity = async (activityId: Id<"activities">) => {
    try {
      await deleteActivity({ activityId });
      toast.success("Activity deleted");
    } catch (error) {
      toast.error("Failed to delete activity");
    }
  };

  const getActivityTypeIcon = (type: string) => {
    switch (type) {
      case "email":
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
        );
      case "call":
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
          </svg>
        );
      case "meeting":
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
        );
      case "task":
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
          </svg>
        );
      default:
        return (
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
          </svg>
        );
    }
  };

  const getActivityTypeColor = (type: string) => {
    switch (type) {
      case "email": return "bg-blue-100 text-blue-800";
      case "call": return "bg-green-100 text-green-800";
      case "meeting": return "bg-purple-100 text-purple-800";
      case "task": return "bg-orange-100 text-orange-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "low": return "bg-green-100 text-green-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-yellow-100 text-yellow-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Activities</h1>
        <button
          onClick={() => setShowCreateForm(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          New Activity
        </button>
      </div>

      {/* Create Activity Form */}
      {showCreateForm && (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Create New Activity</h2>
          <form onSubmit={handleCreateActivity} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <select
                value={newActivity.type}
                onChange={(e) => setNewActivity({...newActivity, type: e.target.value})}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="note">Note</option>
                <option value="email">Email</option>
                <option value="call">Call</option>
                <option value="meeting">Meeting</option>
                <option value="task">Task</option>
              </select>
              <select
                value={newActivity.priority}
                onChange={(e) => setNewActivity({...newActivity, priority: e.target.value})}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="low">Low Priority</option>
                <option value="medium">Medium Priority</option>
                <option value="high">High Priority</option>
              </select>
              <select
                value={newActivity.companyId}
                onChange={(e) => setNewActivity({...newActivity, companyId: e.target.value})}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Select Company (Optional)</option>
                {companies?.map(company => (
                  <option key={company._id} value={company._id}>{company.name}</option>
                ))}
              </select>
            </div>
            <input
              type="text"
              placeholder="Activity Subject"
              value={newActivity.subject}
              onChange={(e) => setNewActivity({...newActivity, subject: e.target.value})}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
            <textarea
              placeholder="Description (optional)"
              value={newActivity.description}
              onChange={(e) => setNewActivity({...newActivity, description: e.target.value})}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={3}
            />
            <input
              type="datetime-local"
              value={newActivity.scheduledDate}
              onChange={(e) => setNewActivity({...newActivity, scheduledDate: e.target.value})}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <div className="flex gap-3">
              <button
                type="submit"
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Create Activity
              </button>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Upcoming Activities */}
      {upcomingActivities && upcomingActivities.length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-yellow-800 mb-4">
            Upcoming Activities ({upcomingActivities.length})
          </h2>
          <div className="space-y-3">
            {upcomingActivities.slice(0, 5).map((activity) => (
              <div key={activity._id} className="flex items-center justify-between bg-white p-3 rounded-lg">
                <div className="flex items-center gap-3">
                  <span className={`p-2 rounded-full ${getActivityTypeColor(activity.type)}`}>
                    {getActivityTypeIcon(activity.type)}
                  </span>
                  <div>
                    <h3 className="font-medium text-gray-900">{activity.subject}</h3>
                    <p className="text-sm text-gray-600">
                      {activity.scheduledDate && new Date(activity.scheduledDate).toLocaleString()}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => handleCompleteActivity(activity._id)}
                  className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
                >
                  Complete
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="flex gap-4">
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <button
            onClick={() => setSelectedStatus("")}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-700"
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Activities List */}
      <div className="bg-white rounded-lg shadow-sm border">
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            All Activities ({activities?.length || 0})
          </h2>
          
          <div className="space-y-4">
            {activities?.map((activity) => {
              const company = companies?.find(c => c._id === activity.companyId);
              
              return (
                <div key={activity._id} className="border border-gray-200 rounded-lg p-4 hover:shadow-sm transition-shadow">
                  <div className="flex justify-between items-start">
                    <div className="flex items-start gap-3">
                      <span className={`p-2 rounded-full ${getActivityTypeColor(activity.type)}`}>
                        {getActivityTypeIcon(activity.type)}
                      </span>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900">{activity.subject}</h3>
                          <span className={`px-2 py-1 text-xs rounded-full ${getPriorityColor(activity.priority || "medium")}`}>
                            {activity.priority || "medium"}
                          </span>
                        </div>
                        
                        {activity.description && (
                          <p className="text-gray-600 text-sm mb-2">{activity.description}</p>
                        )}
                        
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          {company && (
                            <span>Company: {company.name}</span>
                          )}
                          {activity.scheduledDate && (
                            <span>Scheduled: {new Date(activity.scheduledDate).toLocaleString()}</span>
                          )}
                          {activity.completedDate && (
                            <span>Completed: {new Date(activity.completedDate).toLocaleString()}</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(activity.status)}`}>
                        {activity.status}
                      </span>
                      
                      <div className="flex gap-1">
                        {activity.status === "pending" && (
                          <button
                            onClick={() => handleCompleteActivity(activity._id)}
                            className="p-1 text-green-600 hover:text-green-800"
                            title="Complete"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          </button>
                        )}
                        <button
                          onClick={() => handleDeleteActivity(activity._id)}
                          className="p-1 text-red-600 hover:text-red-800"
                          title="Delete"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            
            {activities?.length === 0 && (
              <div className="text-center py-12">
                <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                </svg>
                <h3 className="mt-2 text-sm font-medium text-gray-900">No activities found</h3>
                <p className="mt-1 text-sm text-gray-500">Get started by creating your first activity.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
