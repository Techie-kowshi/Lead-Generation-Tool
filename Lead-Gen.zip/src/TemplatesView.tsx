import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../convex/_generated/dataModel";

export function TemplatesView() {
  const [selectedType, setSelectedType] = useState("");
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<Id<"emailTemplates"> | null>(null);
  const [newTemplate, setNewTemplate] = useState({
    name: "",
    subject: "",
    body: "",
    type: "cold-outreach",
    isDefault: false
  });

  const templates = useQuery(api.emailTemplates.listEmailTemplates, {
    type: (selectedType as any) || undefined
  });
  
  const createTemplate = useMutation(api.emailTemplates.createEmailTemplate);
  const updateTemplate = useMutation(api.emailTemplates.updateEmailTemplate);
  const deleteTemplate = useMutation(api.emailTemplates.deleteEmailTemplate);
  const createDefaults = useMutation(api.emailTemplates.createDefaultTemplates);

  const handleCreateTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingTemplate) {
        await updateTemplate({
          templateId: editingTemplate,
          updates: {
            name: newTemplate.name,
            subject: newTemplate.subject,
            body: newTemplate.body,
            isDefault: newTemplate.isDefault
          }
        });
        toast.success("Template updated successfully");
      } else {
        await createTemplate({
          name: newTemplate.name,
          subject: newTemplate.subject,
          body: newTemplate.body,
          type: newTemplate.type as any,
          isDefault: newTemplate.isDefault
        });
        toast.success("Template created successfully");
      }
      
      setNewTemplate({
        name: "",
        subject: "",
        body: "",
        type: "cold-outreach",
        isDefault: false
      });
      setShowCreateForm(false);
      setEditingTemplate(null);
    } catch (error) {
      toast.error("Failed to save template");
    }
  };

  const handleEditTemplate = (template: any) => {
    setNewTemplate({
      name: template.name,
      subject: template.subject,
      body: template.body,
      type: template.type,
      isDefault: template.isDefault || false
    });
    setEditingTemplate(template._id);
    setShowCreateForm(true);
  };

  const handleDeleteTemplate = async (templateId: Id<"emailTemplates">) => {
    try {
      await deleteTemplate({ templateId });
      toast.success("Template deleted");
    } catch (error) {
      toast.error("Failed to delete template");
    }
  };

  const handleCreateDefaults = async () => {
    try {
      await createDefaults();
      toast.success("Default templates created");
    } catch (error) {
      toast.error("Failed to create default templates");
    }
  };

  const templateTypes = [
    { value: "cold-outreach", label: "Cold Outreach", color: "bg-blue-100 text-blue-800" },
    { value: "follow-up", label: "Follow-up", color: "bg-green-100 text-green-800" },
    { value: "proposal", label: "Proposal", color: "bg-purple-100 text-purple-800" },
    { value: "thank-you", label: "Thank You", color: "bg-orange-100 text-orange-800" }
  ];

  const getTypeColor = (type: string) => {
    const typeConfig = templateTypes.find(t => t.value === type);
    return typeConfig?.color || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Email Templates</h1>
        <div className="flex gap-3">
          {templates?.length === 0 && (
            <button
              onClick={handleCreateDefaults}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              Create Defaults
            </button>
          )}
          <button
            onClick={() => setShowCreateForm(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            New Template
          </button>
        </div>
      </div>

      {/* Template Form */}
      {showCreateForm && (
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            {editingTemplate ? "Edit Template" : "Create New Template"}
          </h2>
          <form onSubmit={handleCreateTemplate} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Template Name"
                value={newTemplate.name}
                onChange={(e) => setNewTemplate({...newTemplate, name: e.target.value})}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
              <select
                value={newTemplate.type}
                onChange={(e) => setNewTemplate({...newTemplate, type: e.target.value})}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                disabled={!!editingTemplate}
              >
                {templateTypes.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
            </div>
            
            <input
              type="text"
              placeholder="Email Subject"
              value={newTemplate.subject}
              onChange={(e) => setNewTemplate({...newTemplate, subject: e.target.value})}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            />
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email Body
              </label>
              <textarea
                placeholder="Email content with variables like {{company_name}}, {{first_name}}, etc."
                value={newTemplate.body}
                onChange={(e) => setNewTemplate({...newTemplate, body: e.target.value})}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                rows={12}
                required
              />
              <p className="text-sm text-gray-500 mt-2">
                Use variables like {"{"}{"{"}{"}"}company_name{"}"}{"}"}{"}"}, {"{"}{"{"}{"}"}first_name{"}"}{"}"}{"}"}, {"{"}{"{"}{"}"}industry{"}"}{"}"}{"}"}, {"{"}{"{"}{"}"}your_name{"}"}{"}"}{"}"} to personalize emails.
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="isDefault"
                checked={newTemplate.isDefault}
                onChange={(e) => setNewTemplate({...newTemplate, isDefault: e.target.checked})}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <label htmlFor="isDefault" className="text-sm text-gray-700">
                Set as default template for this type
              </label>
            </div>
            
            <div className="flex gap-3">
              <button
                type="submit"
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                {editingTemplate ? "Update Template" : "Create Template"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowCreateForm(false);
                  setEditingTemplate(null);
                  setNewTemplate({
                    name: "",
                    subject: "",
                    body: "",
                    type: "cold-outreach",
                    isDefault: false
                  });
                }}
                className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white p-6 rounded-lg shadow-sm border">
        <div className="flex gap-4">
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Types</option>
            {templateTypes.map(type => (
              <option key={type.value} value={type.value}>{type.label}</option>
            ))}
          </select>
          <button
            onClick={() => setSelectedType("")}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-700"
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates?.map((template) => (
          <div key={template._id} className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-gray-900">{template.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`px-2 py-1 text-xs rounded-full ${getTypeColor(template.type)}`}>
                      {templateTypes.find(t => t.value === template.type)?.label}
                    </span>
                    {template.isDefault && (
                      <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                        Default
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={() => handleEditTemplate(template)}
                    className="p-1 text-blue-600 hover:text-blue-800"
                    title="Edit"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                    </svg>
                  </button>
                  <button
                    onClick={() => handleDeleteTemplate(template._id)}
                    className="p-1 text-red-600 hover:text-red-800"
                    title="Delete"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <h4 className="text-sm font-medium text-gray-700">Subject:</h4>
                  <p className="text-sm text-gray-600">{template.subject}</p>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-700">Preview:</h4>
                  <div className="bg-gray-50 p-3 rounded text-sm text-gray-600 max-h-32 overflow-y-auto">
                    {template.body.substring(0, 200)}
                    {template.body.length > 200 && "..."}
                  </div>
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-200">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(template.body);
                    toast.success("Template copied to clipboard");
                  }}
                  className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm flex items-center justify-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  Copy Template
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {templates?.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border p-12 text-center">
          <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
          <h3 className="mt-2 text-lg font-medium text-gray-900">No email templates</h3>
          <p className="mt-1 text-sm text-gray-500">
            Get started by creating your first email template or use our default templates.
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <button
              onClick={handleCreateDefaults}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              Create Default Templates
            </button>
            <button
              onClick={() => setShowCreateForm(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Create Custom Template
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
