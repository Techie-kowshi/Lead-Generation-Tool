import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../convex/_generated/dataModel";

interface CompanyDetailsModalProps {
  companyId: Id<"companies">;
  onClose: () => void;
}

export function CompanyDetailsModal({ companyId, onClose }: CompanyDetailsModalProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<any>({});

  const company = useQuery(api.companies.getCompanyById, { companyId });
  const contacts = useQuery(api.contacts.listContacts, { companyId });
  const activities = useQuery(api.activities.listActivities, { companyId });
  
  const updateCompany = useMutation(api.companies.updateCompany);
  const createContact = useMutation(api.contacts.createContact);
  const createActivity = useMutation(api.activities.createActivity);

  if (!company) return null;

  const handleSave = async () => {
    try {
      await updateCompany({
        companyId,
        updates: editData
      });
      setIsEditing(false);
      setEditData({});
      toast.success("Company updated successfully");
    } catch (error) {
      toast.error("Failed to update company");
    }
  };

  const handleAddContact = async (contactData: any) => {
    try {
      await createContact({
        ...contactData,
        companyId
      });
      toast.success("Contact added successfully");
    } catch (error) {
      toast.error("Failed to add contact");
    }
  };

  const handleAddActivity = async (activityData: any) => {
    try {
      await createActivity({
        ...activityData,
        companyId
      });
      toast.success("Activity added successfully");
    } catch (error) {
      toast.error("Failed to add activity");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{company.name}</h2>
            <p className="text-gray-600">{company.domain}</p>
          </div>
          <div className="flex gap-2">
            {!isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Edit
              </button>
            ) : (
              <>
                <button
                  onClick={handleSave}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                >
                  Save
                </button>
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setEditData({});
                  }}
                  className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                >
                  Cancel
                </button>
              </>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
            >
              Close
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b">
          <nav className="flex space-x-8 px-6">
            {["overview", "contacts", "activities", "notes"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700"
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Company Information</h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Industry</label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editData.industry || company.industry || ""}
                          onChange={(e) => setEditData({...editData, industry: e.target.value})}
                          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
                        />
                      ) : (
                        <p className="text-gray-900">{company.industry || "N/A"}</p>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Size</label>
                      <p className="text-gray-900">{company.size || "N/A"}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Location</label>
                      <p className="text-gray-900">{company.location || "N/A"}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Revenue</label>
                      <p className="text-gray-900">{company.revenue || "N/A"}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Employees</label>
                      <p className="text-gray-900">{company.employees || "N/A"}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Lead Information</h3>
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Lead Score</label>
                      <div className="flex items-center gap-2">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          (company.leadScore || 0) >= 80 ? "bg-green-100 text-green-800" :
                          (company.leadScore || 0) >= 60 ? "bg-yellow-100 text-yellow-800" :
                          "bg-red-100 text-red-800"
                        }`}>
                          {company.leadScore || 0}
                        </span>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Status</label>
                      {isEditing ? (
                        <select
                          value={editData.status || company.status || "new"}
                          onChange={(e) => setEditData({...editData, status: e.target.value})}
                          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
                        >
                          <option value="new">New</option>
                          <option value="contacted">Contacted</option>
                          <option value="qualified">Qualified</option>
                          <option value="proposal">Proposal</option>
                          <option value="closed-won">Closed Won</option>
                          <option value="closed-lost">Closed Lost</option>
                        </select>
                      ) : (
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                          company.status === "new" ? "bg-gray-100 text-gray-800" :
                          company.status === "contacted" ? "bg-blue-100 text-blue-800" :
                          company.status === "qualified" ? "bg-yellow-100 text-yellow-800" :
                          company.status === "proposal" ? "bg-purple-100 text-purple-800" :
                          company.status === "closed-won" ? "bg-green-100 text-green-800" :
                          "bg-red-100 text-red-800"
                        }`}>
                          {company.status?.replace('-', ' ') || "New"}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Tags</label>
                      {isEditing ? (
                        <input
                          type="text"
                          placeholder="Enter tags separated by commas"
                          value={editData.tags?.join(", ") || company.tags?.join(", ") || ""}
                          onChange={(e) => setEditData({...editData, tags: e.target.value.split(",").map(t => t.trim())})}
                          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"
                        />
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {company.tags?.map((tag, index) => (
                            <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                              {tag}
                            </span>
                          )) || <span className="text-gray-500">No tags</span>}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">Description</h3>
                <p className="text-gray-700">{company.description || "No description available"}</p>
              </div>

              {company.technologies && company.technologies.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-4">Technologies</h3>
                  <div className="flex flex-wrap gap-2">
                    {company.technologies.map((tech, index) => (
                      <span key={index} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === "contacts" && (
            <ContactsTab 
              contacts={contacts || []} 
              onAddContact={handleAddContact}
            />
          )}

          {activeTab === "activities" && (
            <ActivitiesTab 
              activities={activities || []} 
              onAddActivity={handleAddActivity}
            />
          )}

          {activeTab === "notes" && (
            <NotesTab 
              company={company}
              isEditing={isEditing}
              editData={editData}
              setEditData={setEditData}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function ContactsTab({ contacts, onAddContact }: any) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newContact, setNewContact] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    title: "",
    department: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddContact(newContact);
    setNewContact({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      title: "",
      department: ""
    });
    setShowAddForm(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Contacts ({contacts.length})</h3>
        <button
          onClick={() => setShowAddForm(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Add Contact
        </button>
      </div>

      {showAddForm && (
        <form onSubmit={handleSubmit} className="bg-gray-50 p-4 rounded-lg space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="First Name"
              value={newContact.firstName}
              onChange={(e) => setNewContact({...newContact, firstName: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md"
              required
            />
            <input
              type="text"
              placeholder="Last Name"
              value={newContact.lastName}
              onChange={(e) => setNewContact({...newContact, lastName: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md"
              required
            />
            <input
              type="email"
              placeholder="Email"
              value={newContact.email}
              onChange={(e) => setNewContact({...newContact, email: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md"
            />
            <input
              type="tel"
              placeholder="Phone"
              value={newContact.phone}
              onChange={(e) => setNewContact({...newContact, phone: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md"
            />
            <input
              type="text"
              placeholder="Title"
              value={newContact.title}
              onChange={(e) => setNewContact({...newContact, title: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md"
            />
            <input
              type="text"
              placeholder="Department"
              value={newContact.department}
              onChange={(e) => setNewContact({...newContact, department: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md"
            />
          </div>
          <div className="flex gap-2">
            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              Add Contact
            </button>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {contacts.map((contact: any) => (
          <div key={contact._id} className="border border-gray-200 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-semibold text-gray-900">
                  {contact.firstName} {contact.lastName}
                </h4>
                {contact.title && (
                  <p className="text-sm text-gray-600">{contact.title}</p>
                )}
                {contact.department && (
                  <p className="text-sm text-gray-500">{contact.department}</p>
                )}
              </div>
              <div className="text-right text-sm">
                {contact.email && (
                  <p className="text-blue-600">{contact.email}</p>
                )}
                {contact.phone && (
                  <p className="text-gray-600">{contact.phone}</p>
                )}
              </div>
            </div>
          </div>
        ))}
        {contacts.length === 0 && (
          <p className="text-gray-500 text-center py-8">No contacts added yet</p>
        )}
      </div>
    </div>
  );
}

function ActivitiesTab({ activities, onAddActivity }: any) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newActivity, setNewActivity] = useState({
    type: "note",
    subject: "",
    description: "",
    scheduledDate: "",
    priority: "medium"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddActivity({
      ...newActivity,
      scheduledDate: newActivity.scheduledDate ? new Date(newActivity.scheduledDate).getTime() : undefined
    });
    setNewActivity({
      type: "note",
      subject: "",
      description: "",
      scheduledDate: "",
      priority: "medium"
    });
    setShowAddForm(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Activities ({activities.length})</h3>
        <button
          onClick={() => setShowAddForm(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Add Activity
        </button>
      </div>

      {showAddForm && (
        <form onSubmit={handleSubmit} className="bg-gray-50 p-4 rounded-lg space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <select
              value={newActivity.type}
              onChange={(e) => setNewActivity({...newActivity, type: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md"
            >
              <option value="note">Note</option>
              <option value="email">Email</option>
              <option value="call">Call</option>
              <option value="meeting">Meeting</option>
              <option value="task">Task</option>
            </select>
            <select
              value={newActivity.priority}
              onChange={(e) => setNewActivity({...newActivity, priority: e.target.value})}
              className="px-3 py-2 border border-gray-300 rounded-md"
            >
              <option value="low">Low Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="high">High Priority</option>
            </select>
          </div>
          <input
            type="text"
            placeholder="Subject"
            value={newActivity.subject}
            onChange={(e) => setNewActivity({...newActivity, subject: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <textarea
            placeholder="Description"
            value={newActivity.description}
            onChange={(e) => setNewActivity({...newActivity, description: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            rows={3}
          />
          <input
            type="datetime-local"
            value={newActivity.scheduledDate}
            onChange={(e) => setNewActivity({...newActivity, scheduledDate: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <div className="flex gap-2">
            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              Add Activity
            </button>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {activities.map((activity: any) => (
          <div key={activity._id} className="border border-gray-200 rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    activity.type === "email" ? "bg-blue-100 text-blue-800" :
                    activity.type === "call" ? "bg-green-100 text-green-800" :
                    activity.type === "meeting" ? "bg-purple-100 text-purple-800" :
                    activity.type === "task" ? "bg-orange-100 text-orange-800" :
                    "bg-gray-100 text-gray-800"
                  }`}>
                    {activity.type}
                  </span>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    activity.priority === "high" ? "bg-red-100 text-red-800" :
                    activity.priority === "medium" ? "bg-yellow-100 text-yellow-800" :
                    "bg-green-100 text-green-800"
                  }`}>
                    {activity.priority}
                  </span>
                </div>
                <h4 className="font-semibold text-gray-900 mt-1">{activity.subject}</h4>
                {activity.description && (
                  <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
                )}
              </div>
              <div className="text-right text-sm text-gray-500">
                {activity.scheduledDate && (
                  <p>{new Date(activity.scheduledDate).toLocaleString()}</p>
                )}
                <span className={`px-2 py-1 text-xs rounded-full ${
                  activity.status === "completed" ? "bg-green-100 text-green-800" :
                  activity.status === "cancelled" ? "bg-red-100 text-red-800" :
                  "bg-yellow-100 text-yellow-800"
                }`}>
                  {activity.status}
                </span>
              </div>
            </div>
          </div>
        ))}
        {activities.length === 0 && (
          <p className="text-gray-500 text-center py-8">No activities recorded yet</p>
        )}
      </div>
    </div>
  );
}

function NotesTab({ company, isEditing, editData, setEditData }: any) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Notes</h3>
      {isEditing ? (
        <textarea
          value={editData.notes || company.notes || ""}
          onChange={(e) => setEditData({...editData, notes: e.target.value})}
          placeholder="Add your notes about this company..."
          className="w-full px-3 py-2 border border-gray-300 rounded-md"
          rows={10}
        />
      ) : (
        <div className="bg-gray-50 p-4 rounded-lg min-h-[200px]">
          {company.notes ? (
            <p className="text-gray-700 whitespace-pre-wrap">{company.notes}</p>
          ) : (
            <p className="text-gray-500 italic">No notes added yet. Click Edit to add notes.</p>
          )}
        </div>
      )}
    </div>
  );
}
